package com.capgemini.drinkanddelight.services;

import java.util.List;

import com.capgemini.drinkanddelight.entities.ProductOrderDetails;

public interface ProductOrderDetailsService {
	 ProductOrderDetails addProductOrder(ProductOrderDetails p);
	    
	    List<ProductOrderDetails>getAllProductDetails();
	    
	    ProductOrderDetails getProductOrderDetailsById(int order_id);
	    
	    ProductOrderDetails deleteProductOrder(int order_id);
	  
	    ProductOrderDetails updateproductorder(ProductOrderDetails p);
}
