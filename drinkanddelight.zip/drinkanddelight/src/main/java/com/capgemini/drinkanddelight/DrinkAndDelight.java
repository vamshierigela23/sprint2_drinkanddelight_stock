package com.capgemini.drinkanddelight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages= {"com.capgemini.drinkanddelight"})
public class DrinkAndDelight {

	public static void main(String[] args) {
		
		SpringApplication.run(DrinkAndDelight.class, args);
		System.out.println("Drink and Delight");
	}
}
