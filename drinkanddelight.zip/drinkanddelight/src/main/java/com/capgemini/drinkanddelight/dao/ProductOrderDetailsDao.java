package com.capgemini.drinkanddelight.dao;

import java.util.List;

import com.capgemini.drinkanddelight.entities.ProductOrderDetails;

public interface ProductOrderDetailsDao {
    ProductOrderDetails addProductOrder(ProductOrderDetails p);
    
    List<ProductOrderDetails>getAllProductDetails();
    
    ProductOrderDetails getProductOrderDetailsById(int order_id);
    
    ProductOrderDetails deleteProductOrder(int order_id);
  
    ProductOrderDetails updateproductorder(ProductOrderDetails p);
}
